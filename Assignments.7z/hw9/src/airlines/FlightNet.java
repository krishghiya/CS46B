package airlines;

import java.util.HashSet;

public class FlightNet extends HashSet<Airport> {
	
	public boolean nameIsAvailable(String name) {
		for(Airport temp: this) if(temp.getName().equals(name)) return false;
		return true;
	}
	
	public void connect(Airport	a1,	Airport	a2) {
		a1.connectTo(a2);
		a2.connectTo(a1);
	}
	
	public void disconnect(Airport	a1,	Airport	a2) {
		a1.disconnectFrom(a2);
		a2.disconnectFrom(a1);
	}
	
	public void removeAndDisconnect(Airport	removeMe) {
		for(Airport temp: this) temp.disconnectFrom(removeMe);
		this.remove(removeMe);
	}
	
	public Airport getAirportNearXY(int x, int y, int maximumDistance) {
		for(Airport temp: this) {
			if(Math.abs(temp.getX()-x)<maximumDistance)
				if(Math.abs(temp.getY()-y)<maximumDistance)
					return temp;
		}
		return null;
	}

}
