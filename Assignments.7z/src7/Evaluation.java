package sudoku;

enum Evaluation 
{
	  ACCEPT, ABANDON, CONTINUE;
}
